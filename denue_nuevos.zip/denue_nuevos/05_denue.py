"""
05_denue.py — DENUE: densidad comercial y competencia por CP / AGEB.

OJO: `cod_postal` del DENUE es DECLARATIVO (lo reporta el negocio), no
geocodificado. Solo concuerda 68-75% con el punto-en-poligono. Los campos
`ageb` y `manzana` SI son geocodificados por INEGI desde lat/lon: usa esos.
"""
import os, zipfile, urllib.request, warnings
import pandas as pd
warnings.filterwarnings("ignore")

BASE = "https://www.inegi.org.mx/contenidos/masiva/denue/denue_{ent}_csv.zip"
COLS = ["nom_estab", "raz_social", "codigo_act", "nombre_act", "per_ocu",
        "cod_postal", "cve_ent", "cve_mun", "municipio", "cve_loc",
        "ageb", "manzana", "latitud", "longitud", "tipoUniEco", "fecha_alta"]
ZONAS = {"cancun": ("23", ["003","005","008","011"]),
         "zmg": ("14", ["039","120","098","101","097","070","044","051","124"])}
OCU = {"0 a 5 personas":3,"6 a 10 personas":8,"11 a 30 personas":20,
       "31 a 50 personas":40,"51 a 100 personas":75,"101 a 250 personas":175,
       "251 y más personas":400}

def baja(ent):
    z = f"denue_{ent}.zip"
    if not os.path.exists(z):
        urllib.request.urlretrieve(BASE.format(ent=ent), z)
    with zipfile.ZipFile(z) as zf:
        n = [x for x in zf.namelist() if "conjunto_de_datos" in x and x.endswith(".csv")][0]
        with zf.open(n) as f:
            return pd.read_csv(f, dtype=str, encoding="latin-1", usecols=COLS)

def main():
    os.makedirs("out", exist_ok=True)
    for z,(ent,muns) in ZONAS.items():
        d = baja(ent)
        d["cve_mun"] = d.cve_mun.str.zfill(3)
        d = d[d.cve_mun.isin(muns)].copy()
        d["CVEGEO"]    = (d.cve_ent.str.zfill(2)+d.cve_mun+d.cve_loc.str.zfill(4)
                          +d.ageb.str.zfill(4)+d.manzana.str.zfill(3))
        d["ageb_full"] = d.CVEGEO.str[:13]
        d["empleo_est"] = d.per_ocu.map(OCU).fillna(3)
        d["cp_declarado"] = d.cod_postal.str.zfill(5)
        d.to_parquet(f"out/denue_{z}.parquet", index=False)

        # agregado por AGEB (llave geocodificada, confiable)
        ag = d.groupby("ageb_full").agg(
            unidades=("CVEGEO","size"), empleo_est=("empleo_est","sum"),
            abarrotes=("codigo_act", lambda s: s.str.startswith("4611").sum()),
            autoservicio=("codigo_act", lambda s: s.str.startswith("4621").sum()),
        ).reset_index().rename(columns={"ageb_full":"CVEGEO_AGEB"})
        ag.to_parquet(f"out/denue_ageb_{z}.parquet", index=False)
        print(f"  {z:<7} {len(d):>7,} unidades | {ag.CVEGEO_AGEB.nunique():>5,} AGEB | "
              f"empleo est. {int(ag.empleo_est.sum()):>9,}")

if __name__ == "__main__":
    main()
