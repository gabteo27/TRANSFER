# CLAUDE.md — Mapa coroplético CP / AGEB (Cancún + ZMG)

Contexto de proyecto para Claude Code. Léelo antes de tocar nada.

## Qué es esto

Pipeline en Python para pintar coropletas de membresías CityClub a nivel
**código postal** y **AGEB**, en dos zonas: Cancún y aledaños, y la ZMG.
Stack: geopandas + plotly (Maplibre, sin token). Corre en AVD.

El objetivo no es el mapa: es **penetración** (socios ÷ población o ÷ viviendas).
Un mapa de conteos absolutos solo dibuja dónde vive más gente y no sirve para
decidir nada.

---

## LO MÁS IMPORTANTE (si solo lees una sección, que sea esta)

### 1. INEGI no tiene código postal ni colonia

La jerarquía del Marco Geoestadístico es
`Entidad → Municipio → Localidad → AGEB → Manzana`. **Manzana es el piso.**
CP y colonia vienen de otras fuentes:

| Unidad | Fuente real |
|---|---|
| CP (polígono) | SEPOMEX / Correos, vía repo `open-mexico/mexico-geojson` |
| Colonia (polígono) | INE, cartografía electoral (`cartografia.ine.mx/sige8`) — **NO probado** |
| AGEB / manzana | INEGI Marco Geoestadístico + Censo 2020 |

Un CP agrupa varias colonias: **CP ⊃ colonia**, no al revés.

### 2. El CRS del MG NO es WGS84

Es Lambert Conforme Cónica ITRF2008 (`MEXICO_ITRF_2008_LCC`). Sin reproyectar,
el `sjoin` devuelve **cero matches sin lanzar error** — falla en silencio.
Siempre `to_crs("EPSG:4326")` para pintar y `EPSG:6372` (metros) para
centroides y áreas.

### 3. El % de AGEB partidos decide la arquitectura, y es distinto por zona

| | Cancún | ZMG |
|---|---|---|
| Manzanas | 18,354 | 60,058 |
| CP en zona | 74 | 411 |
| Cobertura CP | 100% (5 huérfanas) | 100% (0 huérfanas) |
| **AGEB partidos en 2+ CP** | **10.1%** | **21.9%** |
| Peor caso | 3 CP | 5 CP |

- **Cancún (10.1%)**: bajo. CP y AGEB casi intercambiables. Coropleta por CP sin asteriscos.
- **ZMG (21.9%)**: uno de cada cinco AGEB cruza frontera de CP, hasta 5 CP.
  En Guadalajara centro el CP es más fino que el AGEB en unas zonas y más burdo
  en otras — no hay jerarquía limpia. **Ancla a manzana o AGEB; usa el CP solo
  como llave de join** contra la base de membresías.

### 4. Censo 2020, no Intercensal 2025

La Intercensal 2025 publica hasta **septiembre 2026**, y aun así es muestreo
(~7M viviendas) con desglose **máximo municipal**. Nunca baja a AGEB ni manzana.
Para este mapa es inservible. El siguiente censo completo es **2030**.

### 5. Trampas del Censo 2020 (RESAGEBURB) que ya costaron tiempo

- **Jalisco viene en latin-1, Quintana Roo en UTF-8.** Truena si asumes uno solo.
- El archivo mezcla niveles en las mismas filas. Se filtran así:
  - estado → `MUN='000'`
  - **municipio** → `LOC='0000' AND AGEB='0000' AND MZA='000' AND MUN<>'000'`
  - AGEB → `MZA='000' AND AGEB<>'0000'`
  - manzana → `MZA<>'000'`
- Valores suprimidos por confidencialidad vienen como `*` o `N/D` →
  `pd.to_numeric(errors='coerce')`, nunca `astype(int)`.
- **Match geometría ↔ censo: 95.9% Cancún, 93.8% ZMG.** El 4–6% faltante son
  manzanas deshabitadas, industriales o posteriores al corte. No es bug.
- **CP con población 0**: 18 de 73 en Cancún, 41 de 407 en ZMG (zona hotelera,
  industrial, apartados postales). Dividir ahí da infinitos. Ya vienen marcados
  con la bandera `apto_tasa` (piso = 100 hab).
- **11–15% de los CP tienen <10 manzanas.** Cualquier tasa sobre ellos es ruido
  puro y va a dominar visualmente la coropleta. Ponle piso de denominador.

### 6. La clave INEGI es jerárquica concatenada

`CVEGEO = ENTIDAD(2) + MUN(3) + LOC(4) + AGEB(4) + MZA(3)` = 16 chars.
En cuanto un punto cae en una manzana, **los 5 niveles salen por substring**.
No se cruza cinco veces.

---

## URLs verificadas (2026-07-24, HTTP 200)

```
# Marco Geoestadístico Censo 2020, por entidad — UPC 889463807469
https://www.inegi.org.mx/contenidos/productos/prod_serv/contenidos/espanol/bvinegi/productos/geografia/marcogeo/889463807469/23_quintanaroo.zip   # 37 MB
https://www.inegi.org.mx/contenidos/productos/prod_serv/contenidos/espanol/bvinegi/productos/geografia/marcogeo/889463807469/14_jalisco.zip       # 137 MB

# Censo 2020 por AGEB y manzana (RESAGEBURB) — 230 columnas
https://www.inegi.org.mx/contenidos/programas/ccpv/2020/microdatos/ageb_manzana/RESAGEBURB_23_2020_csv.zip   # 3.9 MB
https://www.inegi.org.mx/contenidos/programas/ccpv/2020/microdatos/ageb_manzana/RESAGEBURB_14_2020_csv.zip   # 15 MB

# DENUE (opcional, ver Fase 3)
https://www.inegi.org.mx/contenidos/masiva/denue/denue_23_csv.zip   # 5.9 MB
https://www.inegi.org.mx/contenidos/masiva/denue/denue_14_csv.zip   # 39 MB

# CP (SEPOMEX vía repo)
https://codeload.github.com/open-mexico/mexico-geojson/zip/refs/heads/main   # 78 MB
```

**El UPC del MG cambia con cada edición.** Si `01_descarga.py` truena, abre
`inegi.org.mx/temas/mg/#descargas` con F12 → Network y sustituye `BASE_MG`.
NO bajes el MG nacional integrado (2.65 GB), no se necesita.

Capas MG relevantes: `eem` manzanas · `eea` AGEB urbana · `eear` AGEB rural ·
`eemun` municipio · `eel` localidad. (`eefm` frentes de manzana y `eee` ejes de
vialidad son las pesadas y no se usan.)

---

## Archivos

```
01_descarga.py       baja MG + CP, extrae capas
02_cruce_real.py     centroide de manzana → sjoin contra CP → crosswalk + diagnóstico
03_mapa_plotly.py    módulo de coropleta; expone mapa() y mapa_doble()
04_censo.py          baja RESAGEBURB, arma tablas de denominador

datos/
  crosswalk_<zona>.parquet          CVEGEO manzana → cp, AGEB, MUN, ENT, LOC
  ageb_cp_dominante_<zona>.parquet  AGEB → CP mayoritario
  censo_municipio.parquet           136 municipios (QRoo + Jal completos)
  censo_manzana_<zona>.parquet      manzana + cp + población + viviendas
  censo_cp_<zona>.parquet           <<< la que pegas a tu query de socios
  censo_ageb_<zona>.parquet         igual a nivel AGEB (usar en ZMG)
  cp_<zona>.geojson                 CP recortados, simplificados 0.0001 (~11 m)
  ageb_<zona>.geojson               AGEB urbanas 4326 simplificadas
  mapa_real_<zona>.html             demo end-to-end con datos reales del censo
  mapa_cp_*.html / mapa_ageb_*.html demos con datos aleatorios
```

## Convenciones

- Simplificación de geometría **0.0001 (~11 m)**: mitad de peso, cero pérdida
  visual a zoom 10. Es el punto dulce, no lo cambies sin medir.
- `EPSG:4326` para pintar, `EPSG:6372` para métrica.
- Asignación manzana→CP por **centroide** (rápido, determinista). Existe modo
  por área de traslape (~20x más lento, marginalmente más correcto).
- Nunca inventar un ID cuando el cruce falla. Campo vacío honesto > ID que
  parece dato.

## Municipios en scope

- **Cancún**: QRoo 003 Isla Mujeres · 005 Benito Juárez · 008 Solidaridad · 011 Puerto Morelos
- **ZMG**: Jal 039 Guadalajara · 120 Zapopan · 098 San Pedro Tlaquepaque · 101 Tonalá ·
  097 Tlajomulco · 070 El Salto · 044 Ixtlahuacán de los Membrillos · 051 Juanacatlán · 124 Zapotlanejo

Validación: POBTOT sumado da 1,282,129 (Cancún) y 5,098,304 (ZMG). Cuadra con
las cifras oficiales del AMG 2020.

---

## Uso

```python
from mapa_plotly import mapa
import pandas as pd

socios = pd.read_sql(QUERY, conn)                     # columnas: cp, socios
base   = pd.read_parquet("datos/censo_cp_zmg.parquet")
df = base[base.apto_tasa].merge(socios, on="cp", how="left")
df["penetracion"] = (df.socios.fillna(0) / df.TVIVHAB * 1000).round(2)

fig = mapa("datos/cp_zmg.geojson", df, key="cp", valor="penetracion",
           zona="zmg", titulo="Socios por cada 1,000 viviendas — ZMG")
fig.write_html("penetracion_zmg.html", include_plotlyjs="cdn")
```

---

## PASOS SIGUIENTES

### Fase 0 — validar el entorno AVD (bloqueante, hazlo primero)

`geopandas` y `pyogrio` traen binarios de GDAL. Si pip está restringido en AVD
o no hay compilador, todo lo demás es irrelevante.

```bash
pip install geopandas pyogrio shapely pyarrow plotly
python -c "import geopandas; print(geopandas.__version__)"
```

Si truena: alternativa sin GDAL es preconvertir todo a parquet/geojson en local
y que el AVD solo lea con `pandas` + `plotly` (los geojson ya están generados,
así que esto es viable — solo pierdes la capacidad de re-cruzar).

### Fase 1 — enganchar los datos reales (lo único que falta de verdad)

1. Escribir la query de SQL Server: socios activos agrupados por CP.
2. **Antes de correrla, revisar el `head()` de la tabla de domicilios.** Ahí se
   gana o se pierde la mitad de la tasa de match: depende de cómo capturan la
   dirección los operadores. Si el CP viene sucio (texto libre, con espacios,
   4 dígitos, "N/A"), normalizar con `str.extract(r'(\d{5})')` + `zfill(5)`.
3. Medir tasa de match socios↔CP y reportarla siempre junto al mapa. Un mapa con
   70% de match no es un mapa, es una opinión.
4. Decidir denominador: población (`POBTOT`) para consumo, viviendas
   (`TVIVHAB`) para membresía de hogar. Para CityClub probablemente viviendas.

### Fase 2 — subir de granularidad

Si la base de socios tiene lat/lon: point-in-polygon contra manzana y los 5
niveles salen por substring — exacto, sin repartos. Es superior al CP en todo.
Si no tiene: el crosswalk reparte por CP, con la degradación conocida (21.9% de
AGEB partidos en ZMG).

### Fase 3 — DENUE (solo cuando Fase 1 esté cerrada)

Sirve para: densidad comercial como covariable, competencia geolocalizada por
SCIAN (Sam's, Costco, Bodega, Chedraui), universo prospectable B2B por radio de
club, y siting de nuevos clubs. **No lo mezcles antes** o el scope se dispara.
No trae ventas ni desempeño — es directorio, no panel. Coordenadas son de
fachada: sirven para agregación por AGEB, no para ruteo fino.

### Fase 4 — colonias (solo si el entregable lo exige literalmente)

Frente abierto completo: la cartografía del INE no está probada, no se conoce su
peso ni calidad geométrica. **Antes de abrirlo, confirmar con el solicitante si
"colonia" era literal o era su forma de decir "granularidad fina"** — porque si
es lo segundo, el AGEB ya lo resuelve y con mejor geometría.

---

## Deuda conocida

- Vintage de los CP: el dataset de Correos es de **2017**. Fraccionamientos
  nuevos en Tlajomulco y en el corredor Cancún–Puerto Morelos pueden faltar o
  caer en un CP genérico.
- Densidad de vértices desigual: Jalisco ~315 vértices por polígono, QRoo ~129.
  Los CP de Cancún están trazados más burdos — sirven para coropleta, no para
  geocodificación fina.
- Censo 2020 se levantó en plena pandemia. Para zonas de alta rotación
  (hotelera, Tlajomulco) el denominador puede estar subestimado.
