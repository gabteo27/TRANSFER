"""
03_mapa_plotly.py — Mapa coroplético CP / AGEB con Plotly (Maplibre, sin token).

Uso:
    from mapa_plotly import mapa
    fig = mapa("out/cp_zmg.geojson", df, key="cp", valor="socios", titulo="Socios por CP — ZMG")
    fig.write_html("mapa.html", include_plotlyjs="cdn")

df debe traer una columna con la llave (cp o CVEGEO de AGEB) y una columna numérica.
"""
import json
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

CENTROS = {"cancun": dict(lat=21.10, lon=-86.87, zoom=10.2),
           "zmg":    dict(lat=20.66, lon=-103.36, zoom=9.6)}


def _px_choropleth(**kw):
    """Compatibilidad plotly >=5.24 (choropleth_map) y anteriores (choropleth_mapbox)."""
    if hasattr(px, "choropleth_map"):
        return px.choropleth_map(**kw)
    kw["mapbox_style"] = kw.pop("map_style", "carto-positron")
    return px.choropleth_mapbox(**kw)


def mapa(geojson_path, df, key="cp", valor="valor", titulo="", zona="zmg",
         escala="Blues", rango=None, hover=None):
    geo = json.load(open(geojson_path, encoding="utf-8"))
    prop = key if key in geo["features"][0]["properties"] else \
           list(geo["features"][0]["properties"])[0]
    for f in geo["features"]:
        f["id"] = f["properties"][prop]

    df = df.copy()
    df[key] = df[key].astype(str)
    c = CENTROS.get(zona, CENTROS["zmg"])

    fig = _px_choropleth(
        data_frame=df, geojson=geo, locations=key, color=valor,
        color_continuous_scale=escala,
        range_color=rango or (df[valor].min(), df[valor].max()),
        map_style="carto-positron",
        center={"lat": c["lat"], "lon": c["lon"]}, zoom=c["zoom"],
        opacity=0.72, hover_data=hover or [valor],
        labels={valor: valor.replace("_", " ").title()},
    )
    fig.update_traces(marker_line_width=0.35, marker_line_color="rgba(60,60,60,.55)")
    fig.update_layout(
        title=dict(text=titulo, x=0.01, xanchor="left",
                   font=dict(size=17, family="Segoe UI, sans-serif")),
        margin=dict(l=0, r=0, t=46 if titulo else 0, b=0),
        height=760,
        coloraxis_colorbar=dict(thickness=13, len=0.62, x=0.985,
                                title_side="right", tickformat=",.0f"),
        font=dict(family="Segoe UI, sans-serif"),
    )
    return fig


def mapa_doble(cp_path, ageb_path, df_cp, df_ageb, zona="zmg", titulo=""):
    """Dos capas conmutables: CP (operativa) y AGEB (analítica)."""
    f1 = mapa(cp_path,  df_cp,  key="cp",     valor="valor", zona=zona)
    f2 = mapa(ageb_path, df_ageb, key="CVEGEO", valor="valor", zona=zona, escala="Oranges")
    fig = go.Figure(f1.data + tuple(t.update(visible=False) or t for t in f2.data))
    fig.update_layout(f1.layout)
    fig.update_layout(
        title=titulo,
        updatemenus=[dict(type="buttons", direction="right", x=0.01, y=0.99,
                          buttons=[dict(label="Por CP", method="update",
                                        args=[{"visible": [True, False]}]),
                                   dict(label="Por AGEB", method="update",
                                        args=[{"visible": [False, True]}])])])
    return fig


if __name__ == "__main__":
    import random, os
    for zona in ["cancun", "zmg"]:
        geo = json.load(open(f"out/cp_{zona}.geojson", encoding="utf-8"))
        cps = [f["properties"]["cp"] for f in geo["features"]]
        df = pd.DataFrame({"cp": cps, "valor": [random.randint(0, 1200) for _ in cps]})
        fig = mapa(f"out/cp_{zona}.geojson", df, zona=zona,
                   titulo=f"DEMO — datos aleatorios por CP · {zona.upper()}")
        fig.write_html(f"out/mapa_cp_{zona}.html", include_plotlyjs="cdn")
        print(f"out/mapa_cp_{zona}.html  {os.path.getsize(f'out/mapa_cp_{zona}.html')/1e6:.2f} MB  ({len(cps)} CP)")
