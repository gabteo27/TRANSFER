"""
01_descarga.py — Descarga las dos fuentes. URLs VERIFICADAS el 2026-07-24.

INEGI Marco Geoestadístico, Censo 2020 (UPC 889463807469), por entidad:
    https://www.inegi.org.mx/contenidos/productos/prod_serv/contenidos/espanol/
    bvinegi/productos/geografia/marcogeo/889463807469/<ee>_<estado>.zip

Pesos reales medidos:
    23_quintanaroo.zip   37 MB
    14_jalisco.zip      137 MB
    (nacional integrado  2.65 GB — no lo bajes, no lo necesitas)

Si el UPC cambia con una edición nueva, la ruta se rompe: ábrela desde
inegi.org.mx/temas/mg/#descargas con F12 > Network y sustituye BASE_MG.
"""
import os, zipfile, urllib.request

BASE_MG = ("https://www.inegi.org.mx/contenidos/productos/prod_serv/contenidos/"
           "espanol/bvinegi/productos/geografia/marcogeo/889463807469")
CP_REPO = "https://codeload.github.com/open-mexico/mexico-geojson/zip/refs/heads/main"

ENTIDADES = {"23": "23_quintanaroo", "14": "14_jalisco"}
CAPAS = ["m", "a", "ar", "mun", "l"]      # manzana, AGEB urb, AGEB rural, municipio, localidad


def baja(url, dest):
    if os.path.exists(dest):
        print(f"  ya existe {dest}"); return dest
    print(f"  bajando {url}")
    urllib.request.urlretrieve(url, dest)
    print(f"  -> {dest}  {os.path.getsize(dest)/1e6:.1f} MB")
    return dest


def main():
    os.makedirs("shp", exist_ok=True)

    # --- INEGI ---
    for ent, nom in ENTIDADES.items():
        z = baja(f"{BASE_MG}/{nom}.zip", f"{nom}.zip")
        with zipfile.ZipFile(z) as zf:
            for n in zf.namelist():
                base = os.path.basename(n)
                if base.startswith(tuple(f"{ent}{c}." for c in CAPAS)):
                    with zf.open(n) as src, open(f"shp/{base}", "wb") as out:
                        out.write(src.read())
        print(f"  capas {ent} extraidas")

    # --- CP (SEPOMEX via open-mexico) ---
    z = baja(CP_REPO, "mexico-geojson.zip")
    with zipfile.ZipFile(z) as zf:
        for n in zf.namelist():
            if n.endswith(("23-Qroo.geojson", "14-Jal.geojson")):
                os.makedirs("mexico-geojson-main", exist_ok=True)
                with zf.open(n) as src, open(f"mexico-geojson-main/{os.path.basename(n)}", "wb") as out:
                    out.write(src.read())
    print("listo. corre 02_cruce_real.py")


if __name__ == "__main__":
    main()
