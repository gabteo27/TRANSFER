"""
04_censo.py — Integra el Censo 2020 (RESAGEBURB) al cruce y produce las tablas
              de denominador para calcular penetración.

Salidas en out/:
    censo_municipio.parquet      POBTOT y demás por municipio (los 230 campos filtrados)
    censo_manzana_<zona>.parquet manzana + cp + AGEB + población + viviendas
    censo_cp_<zona>.parquet      <-- ESTA es la que pegas a tu query de socios
    censo_ageb_<zona>.parquet    misma idea a nivel AGEB (recomendada para ZMG)

Ojo con dos trampas reales:
  * Jalisco viene en latin-1, Quintana Roo en UTF-8. Se detecta abajo.
  * Hay CP con población 0 (zona hotelera, industrial, apartados). Si divides
    entre eso te salen infinitos. Se marcan con la bandera `apto_tasa`.
"""
import os, zipfile, urllib.request
import pandas as pd

BASE = ("https://www.inegi.org.mx/contenidos/programas/ccpv/2020/microdatos/"
        "ageb_manzana/RESAGEBURB_{ent}_2020_csv.zip")

ZONAS = {
    "cancun": dict(ent="23", mun=["003", "005", "008", "011"]),
    "zmg":    dict(ent="14", mun=["039", "120", "098", "101", "097",
                                  "070", "044", "051", "124"]),
}

# columnas que realmente sirven; el archivo trae 230
COLS = ["ENTIDAD", "NOM_ENT", "MUN", "NOM_MUN", "LOC", "NOM_LOC", "AGEB", "MZA",
        "POBTOT", "POBFEM", "POBMAS", "P_18YMAS", "P_15A17", "P_60YMAS",
        "PEA", "POCUPADA", "GRAPROES", "PDER_SS",
        "TVIVHAB", "TVIVPARHAB", "PROM_OCUP", "VPH_AUTOM", "VPH_INTER",
        "VPH_REFRI", "VPH_PC", "VPH_CEL"]

PISO_POB = 100      # menos de esto por CP -> la tasa es ruido, no dato


def baja_censo(ent):
    z = f"RESAGEBURB_{ent}.zip"
    if not os.path.exists(z):
        print(f"  bajando censo {ent}...")
        urllib.request.urlretrieve(BASE.format(ent=ent), z)
    with zipfile.ZipFile(z) as zf:
        csv = [n for n in zf.namelist() if n.lower().endswith(".csv")][0]
        with zf.open(csv) as f:
            raw = f.read()
    for enc in ("utf-8", "latin-1"):          # <- Jalisco es latin-1
        try:
            import io
            return pd.read_csv(io.BytesIO(raw), dtype=str, encoding=enc,
                               usecols=lambda c: c in COLS)
        except UnicodeDecodeError:
            continue
    raise RuntimeError(f"no pude decodificar el censo {ent}")


def num(df, cols):
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")   # '*' y 'N/D' -> NaN
    return df


NUMS = [c for c in COLS if c not in
        ("ENTIDAD", "NOM_ENT", "MUN", "NOM_MUN", "LOC", "NOM_LOC", "AGEB", "MZA")]


def main():
    os.makedirs("out", exist_ok=True)
    municipios = []

    for zona, cfg in ZONAS.items():
        d = baja_censo(cfg["ent"])

        # ---- nivel municipio (todos los del estado, no solo la zona) ----
        m = d[(d.LOC == "0000") & (d.AGEB == "0000") & (d.MZA == "000") &
              (d.MUN != "000")].copy()
        m = num(m, NUMS)
        m["CVEGEO"] = m.ENTIDAD + m.MUN
        municipios.append(m.drop(columns=["LOC", "AGEB", "MZA"]))

        # ---- nivel manzana, solo la zona ----
        mz = d[(d.MUN.isin(cfg["mun"])) & (d.MZA != "000") & (d.AGEB != "0000")].copy()
        mz = num(mz, NUMS)
        mz["CVEGEO"] = mz.ENTIDAD + mz.MUN + mz.LOC + mz.AGEB + mz.MZA

        cw = pd.read_parquet(f"out/crosswalk_{zona}.parquet")
        j = cw.merge(mz.drop(columns=["ENTIDAD", "MUN", "LOC", "AGEB", "MZA"]),
                     on="CVEGEO", how="left")
        j.to_parquet(f"out/censo_manzana_{zona}.parquet", index=False)

        agg = {c: "sum" for c in NUMS if c not in ("PROM_OCUP", "GRAPROES")}

        # ---- por CP ----
        cp = j.dropna(subset=["cp"]).groupby("cp").agg(
            **{c: (c, "sum") for c in agg},
            manzanas=("CVEGEO", "count"),
            agebs=("cve_ageb_full", "nunique"))
        cp["apto_tasa"] = (cp.POBTOT >= PISO_POB)
        cp.reset_index().to_parquet(f"out/censo_cp_{zona}.parquet", index=False)

        # ---- por AGEB ----
        ag = j.groupby("cve_ageb_full").agg(
            **{c: (c, "sum") for c in agg},
            manzanas=("CVEGEO", "count"),
            cps=("cp", "nunique"))
        ag["apto_tasa"] = (ag.POBTOT >= PISO_POB)
        ag.reset_index().rename(columns={"cve_ageb_full": "CVEGEO_AGEB"}) \
          .to_parquet(f"out/censo_ageb_{zona}.parquet", index=False)

        print(f"  {zona:<7} manzanas {len(j):>7,} | match censo "
              f"{j.POBTOT.notna().mean()*100:5.1f}% | POBTOT {int(j.POBTOT.sum()):>10,} | "
              f"CP {len(cp)} ({(~cp.apto_tasa).sum()} sin base para tasa)")

    pd.concat(municipios).to_parquet("out/censo_municipio.parquet", index=False)
    print(f"  municipios: {sum(len(m) for m in municipios)} filas")


if __name__ == "__main__":
    main()
