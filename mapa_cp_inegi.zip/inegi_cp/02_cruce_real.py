"""
cruce_real.py — Cruce REAL: manzanas/AGEB del Marco Geoestadístico INEGI 2020
                x polígonos de código postal (SEPOMEX).

Produce por zona:
  crosswalk_<zona>.parquet   CVEGEO(manzana) -> cp, CVE_AGEB, CVE_MUN, CVE_ENT, CVE_LOC
  ageb_<zona>.geojson        AGEB urbanas en 4326, listas para Plotly
  cp_<zona>.geojson          CP recortados a la zona, simplificados
y un diagnóstico impreso.
"""
import geopandas as gpd, pandas as pd, json, os, warnings
warnings.filterwarnings("ignore")

CRS_WGS = "EPSG:4326"
CRS_M   = "EPSG:6372"      # Mexico ITRF2008 LCC -> metros, para áreas/centroides

ZONAS = {
    "cancun": dict(ent="23", src="23-Qroo",
                   mun=["003", "005", "008", "011"]),          # I.Mujeres, Cancún, Solidaridad, Pto Morelos
    "zmg":    dict(ent="14", src="14-Jal",
                   mun=["039", "120", "098", "101", "097",
                        "070", "044", "051", "124"]),          # AMG 9 municipios
}
SHP = "shp"
CPD = "../mexico-geojson-main"


def carga_mza(ent, mun):
    g = gpd.read_file(f"{SHP}/{ent}m.shp")
    g = g[g.CVE_MUN.isin(mun)].to_crs(CRS_WGS)
    return g[["CVEGEO", "CVE_ENT", "CVE_MUN", "CVE_LOC", "CVE_AGEB",
              "CVE_MZA", "AMBITO", "geometry"]].reset_index(drop=True)


def carga_ageb(ent, mun):
    g = gpd.read_file(f"{SHP}/{ent}a.shp")
    return g[g.CVE_MUN.isin(mun)].to_crs(CRS_WGS).reset_index(drop=True)


def carga_cp(src, marco):
    cp = gpd.read_file(f"{CPD}/{src}.geojson").to_crs(CRS_WGS)
    cp["cp"] = cp["d_codigo"].astype(str).str.zfill(5)
    cp = cp[["cp", "geometry"]]
    # recorte espacial: solo CP que tocan la zona
    hull = gpd.GeoSeries([marco.union_all()], crs=CRS_WGS)
    idx = cp.sindex.query(hull.iloc[0], predicate="intersects")
    return cp.iloc[idx].reset_index(drop=True)


def cruza(mza, cp):
    pts = mza[["CVEGEO"]].copy()
    pts["geometry"] = mza.to_crs(CRS_M).centroid.to_crs(CRS_WGS)
    pts = gpd.GeoDataFrame(pts, geometry="geometry", crs=CRS_WGS)
    j = gpd.sjoin(pts, cp, how="left", predicate="within")
    return j[["CVEGEO", "cp"]].drop_duplicates("CVEGEO")


def diagnostico(cw, mza, cp, zona):
    d = mza[["CVEGEO", "CVE_MUN", "CVE_AGEB", "AMBITO"]].merge(cw, on="CVEGEO", how="left")
    d["cve_ageb_full"] = d.CVEGEO.str[:13]
    g = d.dropna(subset=["cp"]).groupby("cve_ageb_full")["cp"].nunique()
    gm = d.dropna(subset=["cp"]).groupby("CVE_MUN")["cp"].nunique()
    ncp = d.dropna(subset=["cp"]).cp.nunique()

    print(f"\n{'='*66}\n{zona.upper()}\n{'='*66}")
    print(f"  manzanas INEGI          : {len(mza):>8,}")
    print(f"  CP en la zona           : {len(cp):>8,}")
    print(f"  manzanas con CP asignado: {d.cp.notna().sum():>8,}  ({d.cp.notna().mean()*100:.1f}%)")
    print(f"  manzanas SIN CP         : {d.cp.isna().sum():>8,}")
    print(f"  CP que reciben manzanas : {ncp:>8,}  (de {len(cp)} -> {ncp/len(cp)*100:.0f}% con carga)")
    print(f"  AGEB totales            : {len(g):>8,}")
    print(f"  AGEB en 1 solo CP       : {(g==1).sum():>8,}")
    print(f"  AGEB partidos en 2+ CP  : {(g>1).sum():>8,}   <<< % PARTIDOS = {(g>1).mean()*100:.1f}%")
    print(f"  AGEB peor caso          : {g.max():>8,} CP distintos")
    print(f"  distribucion CP/AGEB    : {g.value_counts().sort_index().head(6).to_dict()}")
    print(f"  CP por municipio        : {gm.to_dict()}")
    return d


def main():
    os.makedirs("out", exist_ok=True)
    for zona, cfg in ZONAS.items():
        mza  = carga_mza(cfg["ent"], cfg["mun"])
        ageb = carga_ageb(cfg["ent"], cfg["mun"])
        cp   = carga_cp(cfg["src"], mza)
        cw   = cruza(mza, cp)
        d    = diagnostico(cw, mza, cp, zona)

        d.drop(columns=["AMBITO"]).to_parquet(f"out/crosswalk_{zona}.parquet", index=False)

        # CP recortados y simplificados (0.0001 ~ 11 m) para Plotly
        cps = cp.copy(); cps["geometry"] = cps.geometry.simplify(0.0001)
        cps.to_file(f"out/cp_{zona}.geojson", driver="GeoJSON")
        agebs = ageb.copy(); agebs["geometry"] = agebs.geometry.simplify(0.0001)
        agebs.to_file(f"out/ageb_{zona}.geojson", driver="GeoJSON")

        # CP dominante por AGEB (para pintar AGEB con llave CP)
        (d.dropna(subset=["cp"]).groupby(["cve_ageb_full", "cp"]).size()
           .reset_index(name="n").sort_values("n", ascending=False)
           .drop_duplicates("cve_ageb_full")
           .rename(columns={"cve_ageb_full": "CVEGEO_AGEB", "cp": "cp_dominante", "n": "manzanas"})
           .to_parquet(f"out/ageb_cp_dominante_{zona}.parquet", index=False))

    print()
    for f in sorted(os.listdir("out")):
        print(f"  {os.path.getsize('out/'+f)/1e6:8.2f} MB  out/{f}")


if __name__ == "__main__":
    main()
